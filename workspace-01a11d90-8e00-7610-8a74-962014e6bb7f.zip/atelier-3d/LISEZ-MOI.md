# Atelier Impression 3D – site + espace admin

```
index.html              ← le site (catalogue / sur-mesure / infos)
admin/index.html        ← l'espace admin  (votresite.netlify.app/admin/)
netlify/functions/api.mjs + netlify/lib/core.mjs   ← API (mots de passe, produits, photos)
data/products.json      ← produits d'exemple (importables depuis l'admin)
data/filaments.json     ← filaments d'exemple (importables depuis l'admin)
images/                 ← photos « à la main » (facultatif)
dev/server.mjs          ← test local sans Netlify
```

## Mise en ligne (gratuit)

⚠️ L'admin utilise une Netlify Function + Netlify Blobs : il faut un déploiement avec build,
pas un simple glisser-déposer.

1. Créez un dépôt GitHub (privé ou public) et envoyez-y tout ce dossier.
2. Netlify → *Add new site → Import an existing project* → choisissez le dépôt (aucune commande de build à saisir).
3. Netlify → *Site configuration → Environment variables* → ajoutez :
   - `ADMIN_PASSWORD` = votre mot de passe admin (long, unique)
   - (optionnel) `SESSION_SECRET` = une longue chaîne aléatoire
4. Relancez un déploiement (*Deploys → Trigger deploy*), puis ouvrez `/admin/`.
5. Premier lancement : cliquez « Importer les exemples » ou « Partir de zéro ».

Alternative sans GitHub : `npm i -g netlify-cli`, puis `netlify deploy --prod` dans ce dossier.

## Test en local

- `node dev/server.mjs` → http://localhost:8888 (admin : /admin/, mot de passe `test`, données en mémoire).
- `npx netlify dev` → test avec le vrai stockage Netlify.

## Fonctionnement

- Tant que l'admin n'a rien enregistré, le site affiche le tableau `PRODUCTS` de `index.html` (catalogue de secours).
- Dès le premier enregistrement dans l'admin, c'est le catalogue de l'admin qui s'affiche.
- Produit **masqué** (Visible désactivé) : jamais envoyé aux visiteurs (filtré côté serveur).
- Produit **hors stock** : affiché grisé, bouton « Me prévenir ».

- **Filaments** : onglet public « Filaments » + onglet admin du même nom. Tant que vous n'avez rien enregistré côté admin, le site affiche le tableau `FILAMENTS` de `index.html`.
- **Fiche produit** : un clic sur un produit ouvre une fenêtre (image en grand, nom, description détaillée, problèmes possibles). Champs `details` et `issues` (une ligne = un point) dans l'admin ou dans le tableau `PRODUCTS`. Lien partageable : `/#produit/ID`.

// =============================================================
//  Serveur de TEST local (sans Netlify) :  node dev/server.mjs
//  - sert le site statique
//  - émule l'API /api/* avec un stockage EN MÉMOIRE (perdu à l'arrêt)
//  Mot de passe admin de test : "test"   (ou variable ADMIN_PASSWORD)
//  Pour tester avec le vrai stockage Netlify : `npx netlify dev`
// =============================================================
import http from "node:http";
import { readFile } from "node:fs/promises";
import { extname, join, normalize } from "node:path";
import { fileURLToPath } from "node:url";
import { createApi } from "../netlify/lib/core.mjs";

const ROOT = join(fileURLToPath(import.meta.url), "../..");
const PORT = process.env.PORT || 8888;

// Faux "Netlify Blobs" en mémoire (même interface que @netlify/blobs)
const fakeStore = () => {
  const m = new Map();
  return {
    async get(k, o) { const v = m.get(k); if (!v) return null; return o?.type === "json" ? JSON.parse(v.data) : v.data; },
    async setJSON(k, v) { m.set(k, { data: JSON.stringify(v) }); },
    async set(k, v, o) { m.set(k, { data: v, metadata: o?.metadata }); },
    async getWithMetadata(k) { const v = m.get(k); return v ? { data: v.data.buffer ?? v.data, metadata: v.metadata } : null; },
    async list() { return { blobs: [...m.keys()].map((key) => ({ key })) }; },
    async delete(k) { m.delete(k); }
  };
};
const shop = fakeStore(), images = fakeStore();
const api = createApi({ shop: () => shop, images: () => images, env: () => ({ ADMIN_PASSWORD: process.env.ADMIN_PASSWORD ?? "test" }) });

const TYPES = { ".html": "text/html; charset=utf-8", ".json": "application/json", ".js": "text/javascript", ".css": "text/css", ".jpg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".txt": "text/plain" };

http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (url.pathname.startsWith("/api/")) {
    const chunks = []; for await (const c of req) chunks.push(c);
    const body = Buffer.concat(chunks);
    const r = await api(new Request(url, { method: req.method, headers: req.headers, body: ["GET", "HEAD"].includes(req.method) ? undefined : body }));
    res.writeHead(r.status, Object.fromEntries(r.headers));
    return res.end(Buffer.from(await r.arrayBuffer()));
  }
  let p = normalize(decodeURIComponent(url.pathname)).replace(/^(\.\.[/\\])+/, "");
  if (p.endsWith("/") || p === ".") p = join(p, "index.html");
  try {
    const file = await readFile(join(ROOT, p));
    res.writeHead(200, { "Content-Type": TYPES[extname(p)] || "application/octet-stream" });
    res.end(file);
  } catch { res.writeHead(404); res.end("404"); }
}).listen(PORT, "0.0.0.0", () => console.log(`Test local : http://localhost:${PORT}  (admin : /admin/ – mot de passe "test")`));

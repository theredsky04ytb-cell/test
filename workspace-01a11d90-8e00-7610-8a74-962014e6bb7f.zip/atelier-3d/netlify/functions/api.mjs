// =============================================================
//  Point d'entrée Netlify Function  →  /api/*
//  Toute la logique est dans ../lib/core.mjs (testable hors Netlify)
// =============================================================
import { getStore } from "@netlify/blobs";
import { createApi } from "../lib/core.mjs";

const api = createApi({
  // Données du catalogue (JSON) – lecture "strong" = modifications visibles immédiatement
  shop:   () => getStore({ name: "shop",   consistency: "strong" }),
  // Photos uploadées depuis l'admin
  images: () => getStore({ name: "images", consistency: "strong" }),
  env:    () => ({ ADMIN_PASSWORD: Netlify.env.get("ADMIN_PASSWORD"), SESSION_SECRET: Netlify.env.get("SESSION_SECRET") })
});

export default async (req) => api(req);

export const config = { path: "/api/*" };

/* =============================================================
   Service worker – site installable + consultable hors-ligne
   - Pages (navigation) ........ réseau d'abord, sinon dernière version en cache
   - /api/catalog .............. réseau d'abord, sinon dernier catalogue connu
   - Photos (/api/image, /images) et lang-en.js .. cache d'abord (mis à jour en arrière-plan)
   - Admin, login, partage, plan du site ........ JAMAIS mis en cache
   Pour forcer la mise à jour du cache chez tous les visiteurs : changez VERSION.
   ============================================================= */
const VERSION = "v1";
const SHELL = `shell-${VERSION}`, DATA = `data-${VERSION}`, MEDIA = `media-${VERSION}`;

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(SHELL).then((c) => c.addAll(["/", "/manifest.webmanifest", "/icon-192.png"])).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => ![SHELL, DATA, MEDIA].includes(k)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

/** Réseau d'abord ; en cas d'échec, copie en cache */
async function networkFirst(req, cacheName, key = req) {
  const cache = await caches.open(cacheName);
  try {
    const res = await fetch(req);
    if (res.ok) cache.put(key, res.clone());
    return res;
  } catch (err) {
    const hit = await cache.match(key);
    if (hit) return hit;
    throw err;
  }
}

/** Cache d'abord ; mise à jour silencieuse en arrière-plan */
async function cacheFirst(req, cacheName) {
  const cache = await caches.open(cacheName);
  const hit = await cache.match(req);
  const refresh = fetch(req).then((res) => { if (res.ok) cache.put(req, res.clone()); return res; }).catch(() => null);
  return hit || (await refresh) || Response.error();
}

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;                       // CDN (polices, icônes) : géré par le navigateur
  const p = url.pathname;

  if (p.startsWith("/admin") || p.startsWith("/api/admin") || p === "/api/login" || p.startsWith("/api/share") || p === "/api/sitemap") return;

  if (req.mode === "navigate") return void e.respondWith(networkFirst(req, SHELL, "/"));
  if (p === "/api/catalog") return void e.respondWith(networkFirst(req, DATA));
  if (p.startsWith("/api/image/") || p.startsWith("/images/") || p === "/lang-en.js" || /\.(png|webmanifest)$/.test(p)) return void e.respondWith(cacheFirst(req, MEDIA));
});

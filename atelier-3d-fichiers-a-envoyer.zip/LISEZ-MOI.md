# Atelier Impression 3D – site + espace admin

## Fichiers à mettre en ligne (17 fichiers, 2 sous-dossiers)

```
index.html                    ← le site (catalogue, sur-mesure, filaments, galerie, infos)
admin.html                    ← l'espace admin (adresse : votresite.netlify.app/admin)
lang-en.js                    ← traduction anglaise (chargée seulement si le visiteur clique « EN »)
sw.js                         ← mode hors ligne / installation comme une appli
manifest.webmanifest          ← nom + icône de l'appli installable
icon-192.png  icon-512.png  icon-maskable-512.png  apple-touch-icon.png   ← icônes
og-image.png                  ← aperçu lors d'un partage (WhatsApp, Facebook…)
seed-products.json            ← produits d'exemple (importables depuis l'admin)
seed-filaments.json           ← filaments d'exemple (importables depuis l'admin)
netlify.toml                  ← configuration Netlify
package.json                  ← dépendance de l'API
netlify/functions/api.mjs     ← API (mot de passe, produits, photos)
netlify/lib/core.mjs          ← logique de l'API
```

Facultatif : `images/` (vos photos « à la main »), `dev/server.mjs` (test local), ce fichier.

## Mise en ligne (gratuit)

⚠️ Le glisser-déposer Netlify (« Netlify Drop ») ne publie que des sites statiques : `index.html` fonctionne,
mais l'admin (qui a besoin de l'API) NON. Il faut passer par GitHub :

1. Créez un dépôt GitHub et mettez-y les fichiers ci-dessus (voir « Depuis une tablette » si besoin).
2. Netlify → *Add new site → Import an existing project* → choisissez le dépôt (aucune commande de build).
3. Netlify → *Site configuration → Environment variables* → ajoutez `ADMIN_PASSWORD` = votre mot de passe admin (long et unique).
4. *Deploys → Trigger deploy → Deploy site*, puis ouvrez `votresite.netlify.app/admin`.
5. Premier lancement : « Importer les exemples » (produits et filaments) ou « Partir de zéro ».

### Depuis une tablette (sans pouvoir envoyer de dossier)
Sur github.com → votre dépôt :
- **Add file → Upload files** : sélectionnez tous les fichiers « à la racine » de la liste ci-dessus (tout sauf les 2 fichiers `.mjs`) → *Commit changes*. Un fichier déjà présent est simplement remplacé.
- **Add file → Create new file** : dans le champ du nom, tapez `netlify/functions/api.mjs` (les « / » créent les dossiers), collez le contenu du fichier, *Commit changes*. Pour modifier un fichier existant : ouvrez-le → icône crayon → remplacez tout le contenu.
- Recommencez avec `netlify/lib/core.mjs`.

## À faire une seule fois après la mise en ligne (5 minutes)

1. **Adresse du site pour les aperçus de partage** : déjà réglée sur `https://steady-moxie-bc7519.netlify.app` dans `index.html` (à modifier seulement si vous changez de nom de domaine).
2. **Être prévenu des demandes de fichiers 3D** (formulaire « Sur-mesure ») : Netlify → *Forms* → le formulaire `stl-request` apparaît après le 1er déploiement → *Settings & notifications → Form notifications → Add notification → Email notification*. Les fichiers joints se téléchargent dans *Forms*. Gratuit : 100 envois/mois, fichiers de 7,5 Mo maximum.
3. **Statistiques de visites (facultatif)** : créez un compte gratuit sur goatcounter.com, choisissez un code (ex : `monatelier`), puis collez-le dans Admin → Réglages → « Code GoatCounter ». Sans cookie, donc sans bandeau de consentement.
4. **Vos coordonnées** : remplacez `contact@exemple.fr`, `33600000000`, `votre_compte` et les mentions légales (Admin → Réglages, et en bas de `index.html`).
5. **Sauvegarde** : Admin → Réglages → « Télécharger une sauvegarde » (photos comprises). Faites-en une de temps en temps ; l'admin vous le rappelle après 30 jours.

## Fonctionnalités (round 9)
- **Favoris ♥** et **panier** (stockés dans l'appareil du visiteur) → un seul message récapitulatif par WhatsApp / e-mail / Instagram. Pas de paiement en ligne.
- **Photos multiples** par produit (diaporama, 5 maxi), **choix de la couleur** (parmi vos filaments en stock), **prix barré / promo**, pastille **Nouveau**, **duplication** de produit.
- **Estimateur de prix** (onglet Sur-mesure) : fourchette indicative ; tarifs réglables dans Admin → Réglages.
- **Formulaire d'envoi de fichier** (Netlify Forms), **bandeau d'annonce** (congés, promo…).
- **Galerie** de réalisations et **avis clients** (onglet public visible seulement s'il y a du contenu).
- **Version anglaise** (bouton EN) : textes du site traduits dans `lang-en.js` ; pour vos produits, champs « 🇬🇧 English » facultatifs dans la fiche produit (sinon le français est affiché).
- **Partage d'un produit** : lien `/api/share/ID` (aperçu avec photo dans WhatsApp, etc.) ; **sitemap** : `/api/sitemap`.
- **Installable** comme une appli + consultable hors ligne (pages déjà visitées).

### Mise à jour du cache hors ligne
Après une modification importante de `index.html`, changez `VERSION = "v1"` en `"v2"` dans `sw.js` pour forcer la mise à jour chez tous les visiteurs.

## Test en local
- `node dev/server.mjs` → http://localhost:8888 (admin : /admin, mot de passe `test`, données en mémoire ; `/__forms` liste les formulaires reçus).
- `npx netlify dev` → test avec le vrai stockage Netlify.

## Fonctionnement
- Tant que l'admin n'a rien enregistré, le site affiche les tableaux `PRODUCTS` et `FILAMENTS` de `index.html` (catalogue de secours).
- Dès le premier enregistrement dans l'admin, c'est le catalogue de l'admin qui s'affiche.
- Produit **masqué** (Visible désactivé) : jamais envoyé aux visiteurs (filtré côté serveur).
- Produit **hors stock** : affiché grisé, bouton « Me prévenir ».
- **Filaments** : onglet public « Filaments » + onglet admin du même nom.
- **Fiche produit** : un clic ouvre une fenêtre (photos, description, problèmes possibles : une ligne = un point). Lien partageable : `/#produit/ID`.
- **Produits personnalisables** : case « ✨ Personnalisable » + texte « ce qui est personnalisable » (admin). Badge violet, filtre « Personnalisables », avertissement automatique : toute personnalisation est vérifiée avant impression.

## Limites à connaître
- Les photos et données sont stockées dans Netlify Blobs (gratuit, non garanti comme une vraie base) : faites des sauvegardes.
- Les aperçus de partage fonctionnent via `/api/share/ID` ; la page d'accueil seule utilise l'aperçu fixe `og-image.png`. Les produits ne sont pas indexés individuellement par Google (le site est une application à onglets).
- Netlify Forms : quota gratuit de 100 envois/mois ; au-delà, les envois sont bloqués (le visiteur peut toujours écrire par e-mail / WhatsApp).
- Les estimations de prix sont indicatives, jamais un engagement.

## Si le build échoue avec « Secrets scanning found secrets »
Votre `ADMIN_PASSWORD` est un mot court ou courant qui apparaît dans les fichiers (ex : « test », « admin »).
Choisissez un mot de passe long et unique (16+ caractères, lettres + chiffres + symboles) dans *Environment variables*, puis relancez un déploiement.
`netlify.toml` contient aussi `SECRETS_SCAN_OMIT_KEYS` pour éviter ce faux positif.
